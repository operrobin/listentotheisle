<?php 
$server = "127.0.0.1";
$dbname = "listentotheisle_subscribe";
$dbuser = "listentotheisle_yana123";
$dbpass = "qwe123ASD!@#";
$dbport = "3306";
$dbcharset = "utf8";
$message = "";

$options = array(PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ, PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING);
try {
	$conn = new PDO("mysql:host=$server;dbname=$dbname;port=$dbport;charset=$dbcharset", $dbuser, $dbpass, $options);
} catch(PDOException $e){
	echo "Connect failed" . $e->getMessage();
}

if(isset($_POST["submit"])){
	$email = $_POST["email"];
	if(empty($email)) {
		$message = "EMAIL CANNOT BE EMPTY";
	} else {
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			$message = "WRONG EMAIL";
		} else {
			$sql = "INSERT INTO email_subscribe(email) VALUES(:email)";
			$query = $conn->prepare($sql);
			$query->execute([":email" => $email]);
			$count =  $query->rowCount();
			if ($count == 1) {
				$message = "THANK YOU FOR SUBSCRIBE";
			} else {
				$message = "EMAIL SENDING FAILED";
			}
		}
	}
}

?>
<!doctype html>
<html class="no-js" lang="">
<head>
	<meta charset="utf-8">
	<title>COMING SOON</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<meta property="og:title" content="">
	<meta property="og:type" content="">
	<meta property="og:url" content="">
	<meta property="og:image" content="">
	<link rel="apple-touch-icon" href="icon.png">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/fonts.css">
	<link rel="stylesheet" href="css/general.css">
	<link rel="stylesheet" href="css/main.css">
	<link rel="stylesheet" href="css/landing_page.css">
	<meta name="theme-color" content="#fafafa">
</head>

<body class="landing_page background_red">
	<div id="header_line" class="small_height">
		<div class="full_text_wrapper background_dark">
			<div class="outer">
				<div>
					<div class="loop">
						<div class="content">
							<span style="display: inline-block;color: #FFAB1C;font-size: 26px;line-height:32px;vertical-align: middle;">WATCH LISTEN DANCE /</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="background_landing" class="body_height_landing_page">
		<div class="wrapper double_padding_top padding_left padding_right">
			<h1 class="bigger">ISLE IS A COOPERATIVE ORGANIZATION DESIGNED TO SERVE THE PURPOSE OF PROVIDING VARIOUS COLLECTIVES MUSICAL GENRES, THAT ARE PROPERLY ARCHIVED IN OUR DATABASE THAT CAN BE ACCESSED BY EVERYONE. THE ORGANIZATION ALSO GIVES A WIDE RANGE OF MUSICAL KNOWLEDGE FOR OUR LISTENERS. TO BE BRIEF, ISLE IS A PROVIDER FOR LIVE MIXES THAT CAN BE HEARD AND DOWNLOADED FOR FREE BY ALL MUSIC ENTHUSIASTS.</h1>
			<h2 class="bolder">SUBSCRIBE RIGHT NOW<br>AND GET UPDATE.</h2>
			<div class="half_wrapper">
				<form id="form_subscribe" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
					<input class="input_email" type="text" name="email" placeholder="<?php echo (!empty($message) ? $message : "YOUR EMAIL"); ?>">
					<input class="button_subscribe" type="submit" name="submit" value="SUBSCRIBE">
				</form>
				<!--<div class="form_message"><?php echo $message; ?></div>-->
			</div>
			<h2 class="bolder">@LISTENTOISLE<br>CONTACT@LISTENTOISLE.COM</h2>
		</div>
	</div>
	<div id="footer_line" class="small_height">
		<div class="full_text_wrapper background_dark">
			<div class="outer">
				<div>
					<div class="loop">
						<div class="content">
							<span style="display: inline-block;color: #FFAB1C;font-size: 26px;line-height:32px;vertical-align: middle;">WATCH LISTEN DANCE /</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- JS Scripts -->
	<script src="js/jquery-3.5.1.min.js"></script>
	<script src="js/plugins.js"></script>
</body>
</html>
