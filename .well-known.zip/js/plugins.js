$(function(){
	for (let outer of document.querySelectorAll(".outer")) {
		let content = outer.querySelector(".content");
		repeatContent(content, outer.offsetWidth);

		let el = outer.querySelector(".loop");
		el.innerHTML = el.innerHTML + el.innerHTML;
	}

	function repeatContent(el, till) {
		let html = el.innerHTML;
		let counter = 0;
		while (el.offsetWidth < till && counter < 100) {
			el.innerHTML += html;
			el.innerHTML += el.innerHTML;
			console.log(el.offsetWidth, till);
			counter += 1;
		}
	}
	
	var O = {
		clickMenu: function(el) {
			$(el).on("click", function(e){
				var target = $(this).attr("data-target"),
					menu = $(this).attr("data-menu");
				if(!target) return;
				e.stopPropagation();
				if($(target).is(":hidden")){
					$(menu).animate({
						top: "-100%"
					});
					$(target).animate({
						top: "0%"
					});
					$(target).css({
						"display":"block"
					});
				} else {
					$(menu).animate({
						top: "0%"
					});
					$(target).animate({
						top: "-100%"
					},500,function(){
						$(target).css({
							"display":"none"
						});
					});
				}
			});
		},
		hLink: function(el){
			$(el).on("click", function(e){
				var url = $(this).attr("data-href");
				if(!url) return;
				e.stopPropagation();
				window.location.replace(url);
			});
		},
		init: function(){
			O.hLink(".link_href");
			O.clickMenu(".show_menu");
		}
	};
	
	O.init();
	
});
